﻿using Contracts.Interfaces;
using System;

namespace SuperAdminService
{
    public class SuperAdminService : ISuperAdminService
    {
    }
}
