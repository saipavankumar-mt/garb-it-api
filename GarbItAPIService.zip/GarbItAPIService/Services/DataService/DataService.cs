﻿using Contracts.Interfaces;
using System;

namespace DataService
{
    public class DataService : IDataService
    {
    }
}
